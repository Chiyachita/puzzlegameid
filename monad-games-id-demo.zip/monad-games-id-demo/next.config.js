
/** @type {import('next').NextConfig} */
const nextConfig = {
  experimental: {},
};
export default nextConfig;
