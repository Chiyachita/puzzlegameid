
# Monad Games ID — Puzzle Leaderboard Demo (Next.js + Vercel)

This repo is a zero-install starter to integrate **Monad Games ID** into a web game:
- Sign in with Monad Games ID (Privy Cross App)
- Get the player's embedded wallet address
- Lookup username via provided API (proxied)
- Start/finish a timed run (server measures time)
- Award **on-chain points** via `updatePlayerData` (viem, server-side)

## Deploy (Option 3 — Direct GitHub + Vercel)

1. Create a new repo on GitHub and upload this folder (or just upload the ZIP).
2. Go to https://vercel.com → **New Project** → Import your repo.
3. In Vercel Project Settings → **Environment Variables**, add:

- `NEXT_PUBLIC_PRIVY_APP_ID` = your Privy App ID from Privy Dashboard
- `NEXT_PUBLIC_MONAD_GAMES_CROSS_APP_ID` = `cmd8euall0037le0my79qpz42`
- `MONAD_TESTNET_RPC` = `https://testnet-rpc.monad.xyz`
- `SERVER_PRIVATE_KEY` = `0x...` (server signer private key; DO NOT commit to repo)
- `GAMES_ID_CONTRACT` = `0xceCBFF203C8B6044F52CE23D914A1bfD997541A4`

4. Deploy. You get a public URL. Login → Start Run → Finish & Submit to test.

> For production, use a shared store (Redis/KV/DB) instead of the in-memory Map used in this demo.

## Local Dev (optional)
```bash
npm i
npm run dev
```
Open http://localhost:3000

## Notes
- The in-memory run store resets on redeploy/scale. Replace with Redis/KV for real usage.
- Keep the points formula consistent across games if you want fair global leaderboards.
- Cross App ID is **not** your Privy App ID; you need both.
