
export async function GET(request) {
  const { searchParams } = new URL(request.url);
  const wallet = searchParams.get('wallet');
  if (!wallet) return Response.json({ error: 'wallet missing' }, { status: 400 });

  try {
    const upstream = `https://monad-games-id-site.vercel.app/api/check-wallet?wallet=${wallet}`;
    const res = await fetch(upstream, { method: 'GET', cache: 'no-store' });
    const data = await res.json();
    return Response.json(data, { status: res.ok ? 200 : 500 });
  } catch (e) {
    return Response.json({ error: e.message || 'lookup failed' }, { status: 500 });
  }
}
