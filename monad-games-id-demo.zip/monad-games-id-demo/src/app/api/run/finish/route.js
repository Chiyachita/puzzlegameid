
import { getWallet } from '@/lib/viemClient';
import { gamesIdAbi } from '@/lib/gamesIdAbi';

const contractAddress = process.env.GAMES_ID_CONTRACT;
const runs = globalThis.__RUNS__ ?? (globalThis.__RUNS__ = new Map());
const TTL_MS = 5 * 60 * 1000;

export async function POST(req) {
  try {
    const { runId, boardProof } = await req.json();
    if (!runId) return Response.json({ error: 'runId missing' }, { status: 400 });

    const item = runs.get(runId);
    if (!item) return Response.json({ error: 'invalid runId' }, { status: 400 });
    if (item.used) return Response.json({ error: 'run already finished' }, { status: 400 });
    if (Date.now() > (item.expiresAt ?? (item.serverStart + TTL_MS))) {
      runs.delete(runId);
      return Response.json({ error: 'run expired' }, { status: 400 });
    }

    // TODO: verify your puzzle completion proof here
    if (!boardProof || !boardProof.ok) {
      return Response.json({ error: 'invalid board proof' }, { status: 400 });
    }

    const now = Date.now();
    const elapsedMs = Math.max(1, now - item.serverStart);
    const points = Math.max(1, Math.floor(1_000_000_000 / elapsedMs)); // faster -> more points

    const wallet = getWallet();
    const hash = await wallet.writeContract({
      address: contractAddress,
      abi: gamesIdAbi,
      functionName: 'updatePlayerData',
      args: [item.playerAddress, BigInt(points), 1n],
    });

    item.used = true;
    runs.set(runId, item);

    return Response.json({ elapsedMs, points, txHash: hash });
  } catch (e) {
    return Response.json({ error: e.message || 'finish failed' }, { status: 500 });
  }
}
