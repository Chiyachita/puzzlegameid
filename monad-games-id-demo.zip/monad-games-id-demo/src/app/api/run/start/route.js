
const runs = globalThis.__RUNS__ ?? (globalThis.__RUNS__ = new Map());
const TTL_MS = 5 * 60 * 1000;

export async function POST(req) {
  try {
    const { playerAddress } = await req.json();
    if (!playerAddress) return Response.json({ error: 'playerAddress missing' }, { status: 400 });

    const now = Date.now();
    const runId = crypto.randomUUID();
    runs.set(runId, { playerAddress, serverStart: now, used: false, expiresAt: now + TTL_MS });

    return Response.json({ runId, serverStart: new Date(now).toISOString() });
  } catch (e) {
    return Response.json({ error: e.message || 'start failed' }, { status: 500 });
  }
}
