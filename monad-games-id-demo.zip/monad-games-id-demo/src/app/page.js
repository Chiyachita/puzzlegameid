
'use client';

import { useEffect, useState } from 'react';
import { usePrivy } from '@privy-io/react-auth';

const btn = { padding: '10px 14px', border: '1px solid #444', borderRadius: 10, cursor: 'pointer' };
const inp = { width: '100%', padding: 8, borderRadius: 8, border: '1px solid #555' };
const short = (a) => (a ? `${a.slice(0, 6)}...${a.slice(-4)}` : '');

export default function Page() {
  const { ready, authenticated, user, login, logout } = usePrivy();
  const [account, setAccount] = useState('');
  const [username, setUsername] = useState('');
  const [startData, setStartData] = useState(null);
  const [status, setStatus] = useState('');

  // pull embedded wallet created via Cross App = Monad Games ID
  useEffect(() => {
    if (!ready || !authenticated || !user) return;

    try {
      const crossAppId = process.env.NEXT_PUBLIC_MONAD_GAMES_CROSS_APP_ID;
      const crossApps = (user.linkedAccounts || []).filter(
        (a) => a.type === 'cross_app' && a?.providerApp?.id === crossAppId
      );
      if (crossApps.length === 0) {
        setStatus('Link your Monad Games ID first.');
        return;
      }
      const wallets = crossApps[0].embeddedWallets || [];
      if (wallets.length === 0) {
        setStatus('No embedded wallet; try re-login.');
        return;
      }
      const addr = wallets[0].address;
      setAccount(addr);

      // username lookup (proxied)
      fetch(`/api/username?wallet=${addr}`)
        .then((r) => r.json())
        .then((d) => setUsername(d?.hasUsername ? d.user.username : '— none —'))
        .catch(() => setUsername('lookup failed'));
    } catch (e) {
      setStatus(`Error: ${e.message || e}`);
    }
  }, [ready, authenticated, user]);

  const startRun = async () => {
    setStatus('Starting run...');
    const r = await fetch('/api/run/start', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ playerAddress: account }),
    });
    const j = await r.json();
    if (!r.ok) return setStatus(`Start failed: ${j.error || 'unknown'}`);
    setStartData(j);
    setStatus(`Run started. ID: ${j.runId}`);
  };

  const finishRun = async () => {
    if (!startData) return setStatus('Start a run first.');
    setStatus('Finishing run...');
    const r = await fetch('/api/run/finish', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ runId: startData.runId, boardProof: { ok: true } }),
    });
    const j = await r.json();
    if (!r.ok) return setStatus(`Finish failed: ${j.error || 'unknown'}`);
    setStatus(`OK · ${j.elapsedMs}ms · +${j.points} pts · tx: ${short(j.txHash)}`);
  };

  return (
    <main style={{ padding: 24, maxWidth: 720, margin: '0 auto', display: 'grid', gap: 16 }}>
      <h1>Monad Games ID — Puzzle Leaderboard Demo</h1>

      {!ready ? (
        <div>Loading auth…</div>
      ) : authenticated ? (
        <>
          <div>Wallet: <b>{short(account) || '-'}</b></div>
          <div>Username: <b>{username || '...'}</b></div>
          <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}>
            <button onClick={startRun} style={btn}>Start Run</button>
            <button onClick={finishRun} style={btn}>Finish & Submit</button>
            <button onClick={logout} style={btn}>Logout</button>
          </div>

          <div style={{ opacity: 0.8 }}>
            <p><i>Tip:</i> Wire these buttons to your actual puzzle's start/completion events.</p>
          </div>

          <section>
            <h3>Debug</h3>
            <label>Run ID<br/><input readOnly value={startData?.runId || ''} style={inp} /></label>
            <label>Server started at<br/><input readOnly value={startData?.serverStart || ''} style={inp} /></label>
          </section>

          <div>{status}</div>
        </>
      ) : (
        <>
          <button onClick={login} style={btn}>Sign in with Monad Games ID</button>
        </>
      )}
    </main>
  );
}
