
'use client';
import { PrivyProvider } from '@privy-io/react-auth';

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <body>
        <PrivyProvider
          appId={process.env.NEXT_PUBLIC_PRIVY_APP_ID}
          config={{
            loginMethodsAndOrder: [
              {
                type: 'cross_app',
                crossAppId: process.env.NEXT_PUBLIC_MONAD_GAMES_CROSS_APP_ID,
                label: 'Sign in with Monad Games ID',
              },
            ],
            embeddedWallets: { createOnLogin: 'users-without-wallets' },
            appearance: { theme: 'dark' },
          }}
        >
          {children}
        </PrivyProvider>
      </body>
    </html>
  );
}
